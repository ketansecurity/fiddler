﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MyFiddlerExtensionApp : IAutoTamper, IHandleExecAction
    {
        private bool m_bExtensionEnabled = false;
        private HostList m_hlBlockedHosts;
        private string m_sDefaultBlockedHostList = "www.apple.com; www.google.com";

        void InitializeConfig()
        {
            /*
            m_bExtensionEnabled = false;
            m_hlBlockedHosts = new HostList();
            if (m_hlBlockedHosts != null)
                m_hlBlockedHosts.AssignFromString(m_sDefaultBlockedHostList);
            */ 
        }
        
        void LoadConfig()
        {
            /*
            string sHostList = FiddlerApplication.Prefs.GetStringPref("ext.$safeprojectname$.BlockHosts", null);
            if (!String.IsNullOrEmpty(sHostList))
            {
                m_hlBlockedHosts.AssignFromString(sHostList);
            }
            */ 
        }

        void SaveConfig()
        {
            /*
            FiddlerApplication.Prefs.SetStringPref("ext.$safeprojectname$.BlockHosts", m_hlBlockedHosts.ToString());
            */ 
        }         
    }
}