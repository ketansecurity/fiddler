﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MyFiddlerExtensionApp : IAutoTamper, IHandleExecAction
    {
        private System.Windows.Forms.MenuItem mnuMyExtension;
        private System.Windows.Forms.MenuItem miMyExtensionEnabled;
        private System.Windows.Forms.MenuItem miSplit1;
        private System.Windows.Forms.MenuItem miModifyBlockedHostList;

        void InitializeMenu()
        {
            /*
            mnuMyExtension = new System.Windows.Forms.MenuItem();
            miMyExtensionEnabled = new System.Windows.Forms.MenuItem();
            miSplit1 = new System.Windows.Forms.MenuItem();
            miModifyBlockedHostList = new System.Windows.Forms.MenuItem();

            mnuMyExtension.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                        miMyExtensionEnabled,
                                                                                        miSplit1,
                                                                                        miModifyBlockedHostList,                                                                                        
                                                        });
            mnuMyExtension.Text = "MyExtension-Off";
            //Enable extension
            miMyExtensionEnabled.Index = 0;
            miMyExtensionEnabled.Text = "Enable";
            miMyExtensionEnabled.Click += new System.EventHandler(miMyExtensionEnabled_Click);
            //Splitter 
            miSplit1.Index = 1;
            miSplit1.Text = "-";
            //ModifyBlockedHost
            miModifyBlockedHostList.Index = 2;
            miModifyBlockedHostList.Enabled = false;
            miModifyBlockedHostList.Text = "Modify Blocked Hostlist...";
            miModifyBlockedHostList.Click += new System.EventHandler(miEditBlockedHosts_Click);
            */ 
        }

        private void LoadMenu()
        {
            /*
            FiddlerApplication.UI.mnuMain.MenuItems.Add(mnuMyExtension);
            */ 
        }

        private void miMyExtensionEnabled_Click(object sender, System.EventArgs e)
        {
            MenuItem oSender = (sender as MenuItem);
            MenuEnableDisable(!oSender.Checked);
        }

        private void MenuEnableDisable(bool bEnable)
        {
            miMyExtensionEnabled.Checked = bEnable;
            m_bExtensionEnabled = bEnable;
            if (m_bExtensionEnabled)
            {
                mnuMyExtension.Text = "MyExtension-On";
            }
            else
            {
                mnuMyExtension.Text = "MyExtension-Off";
            }

            miSplit1.Enabled = miModifyBlockedHostList.Enabled = m_bExtensionEnabled;
        }

        private void miEditBlockedHosts_Click(object sender, System.EventArgs e)
        {
            string sNewList = frmPrompt.GetUserString("Modify Blocked Hostist",
                                                      "Enter semicolon-delimited hosts to block.", m_hlBlockedHosts.ToString(), true);
            if (null == sNewList)
            {
                FiddlerApplication.UI.sbpInfo.Text = "No change to blocked hostlist.";
                return;
            }
            else
            {
                string sErrors;
                if (!m_hlBlockedHosts.AssignFromString(sNewList, out sErrors))
                {
                    MessageBox.Show(sErrors, "An Error Occured While Parsing Blocked Hostist");
                }
                else
                {
                    FiddlerApplication.UI.sbpInfo.Text = "Blocked HostList Updated.";
                }
            }
        }
    }
}