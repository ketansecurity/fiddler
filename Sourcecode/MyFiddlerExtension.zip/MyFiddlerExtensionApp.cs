﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

[assembly: Fiddler.RequiredVersion("4.4.5.1")]
namespace $safeprojectname$
{
    public partial class MyFiddlerExtensionApp : IAutoTamper, IHandleExecAction
    {
        public MyFiddlerExtensionApp()
        {
            InitializeConfig();
            InitializeMenu();
        }

        public void OnLoad()
        {
            LoadConfig();
            LoadMenu();
        }

        public void OnBeforeUnload()
        {
            SaveConfig();
        }

        public void AutoTamperRequestBefore(Session oSession) 
        {
            CheckHost(oSession);
        }
        public void AutoTamperRequestAfter(Session oSession) { }
        public void AutoTamperResponseBefore(Session oSession) { }
        public void AutoTamperResponseAfter(Session oSession) { }
        public void OnBeforeReturningError(Session oSession) { }
    }
}


