﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MyFiddlerExtensionApp : IAutoTamper, IHandleExecAction
    {
        public bool OnExecAction(string sCommand)
        {            
            bool bRetVal = false;
            
            /*
            if (String.Equals(sCommand, "EnableMyExtension", StringComparison.OrdinalIgnoreCase))
            {
                MenuEnableDisable(true);
                bRetVal = true;
            }
            else if (String.Equals(sCommand, "DisableMyExtension", StringComparison.OrdinalIgnoreCase))
            {
                MenuEnableDisable(false);
                bRetVal = true;
            }
            */
            return bRetVal;
        }
    }
}