﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MyFiddlerExtensionApp : IAutoTamper, IHandleExecAction
    {
        void CheckHost(Session oSession)
        {
            /*
            if (m_bExtensionEnabled)
            {
                string sHost = oSession.host.ToLower();
                if (m_hlBlockedHosts.ContainsHost(sHost))
                {
                    oSession.oRequest.FailSession(404, "This host is banned by MyExtension", String.Format("Blocked - Host {0} in Url {1} is part of blocked host list", oSession.host, oSession.fullUrl));
                    oSession.state = SessionStates.Done;
                }
            }
            */ 
        }
    }
}