﻿import System;
import System.Windows.Forms;
import System.Environment;
import System.String;
import Fiddler;


class Handlers
{    
    //General Functions
    static function Main() 
    {
        var today: Date = new Date();
        FiddlerObject.StatusText = "G0S Training - Fiddler Rules loaded at: " + today + " on your computer";                                
         
        MessageBox.Show("Script is loaded");                
    }
        
    static function OnAttach() {
        
        MessageBox.Show("Fiddler is Attached as System Proxy");
    }            
        
    static function OnBoot() 
    {        
        var sOsVersion = new String();
        sOsVersion = System.Environment.OSVersion.ToString();        
        MessageBox.Show(sOsVersion, "Operating System Version", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }  
            
    static function OnShutdown() 
    {       
        var shutdownPrompt: DialogResult;               
        shutdownPrompt = MessageBox.Show("Fiddler is shutting down, do you want to save current session?", 
            "Save Session", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, 
            MessageBoxDefaultButton.Button1);               
        
        if (DialogResult.Yes != shutdownPrompt)  
        {  
            //Don't save the session
            return;  
        }  
             
        FiddlerApplication.UI.actSelectAll();  
        FiddlerApplication.UI.actSaveSessionsToZip(); 
        
    }

    static function OnDetach() {
        
        MessageBox.Show("Fiddler is Detached as System Proxy");

    }       
        
    static function OnRetire()
    {
        MessageBox.Show("Script is retiring");                
    }     
            
       
    // The OnExecAction function is called by either the QuickExec box in the Fiddler window,
    // or by the ExecAction.exe command line utility. Return true if your script has handled the specified command, 
    // otherwise return false.
    static function OnExecAction(sParams: String[]): Boolean {

        FiddlerObject.StatusText = "ExecAction: " + sParams[0];

        var sAction = sParams[0].toLowerCase();
        switch (sAction) {
            case "stop":
                FiddlerObject.UI.actDetachProxy();
                return true;
            case "start":
                FiddlerObject.UI.actAttachProxy();
                return true;
            case "cls":
            case "clear":
                FiddlerObject.UI.actRemoveAllSessions();
                return true;
            case "g":
            case "go":
                FiddlerObject.UI.actResumeAllSessions();
                return true;
            case "goto":
                if (sParams.Length != 2) return;
                Utilities.LaunchHyperlink("http://www.google.com/search?hl=en&btnI=I%27m+Feeling+Lucky&q=" + Utilities.UrlEncode(sParams[1]));
                return true;
            case "help":
                Utilities.LaunchHyperlink("http://fiddler2.com/r/?quickexec");
                return true;
            case "hide":
                FiddlerObject.UI.actMinimizeToTray();
                return true;
            case "log":
                FiddlerApplication.Log.LogString((sParams.Length<2) ? FiddlerApplication.Log.LogString("User couldn't think of anything to say...") : sParams[1]);
                return true;
            case "nuke":
                FiddlerObject.UI.actClearWinINETCache();
                FiddlerObject.UI.actClearWinINETCookies(); 
                return true;
            case "screenshot":
                FiddlerApplication.UI.actCaptureScreenshot(false);
                return true;
            case "show":
                FiddlerObject.UI.actRestoreWindow();
                return true;
            case "tail":
                if (sParams.Length<2) { FiddlerObject.StatusText="Please specify # of sessions to trim the session list to."; return;}
                FiddlerObject.UI.TrimSessionList(int.Parse(sParams[1]));
                return true;
            case "quit":
                FiddlerObject.UI.actExit();
                return true;
            case "dump":
                FiddlerObject.UI.actSelectAll();
                FiddlerObject.UI.actSaveSessionsToZip(CONFIG.GetPath("Captures") + "dump.saz");
                FiddlerObject.UI.actRemoveAllSessions();
                FiddlerObject.StatusText = "Dumped all sessions to " + CONFIG.GetPath("Captures") + "dump.saz";
                return true;
            case "g0s":
                System.Diagnostics.Process.Start("http://g0s.org");
                return true;
            default:
                if (sAction.StartsWith("http") || sAction.StartsWith("www")){
                    System.Diagnostics.Process.Start(sParams[0]);
                    return true;
                }
                else
                {
                    FiddlerObject.StatusText = "Requested ExecAction: '" + sAction + "' not found. Type HELP to learn more.";
                    return false;
                }
        }   
    }                          
}            
                
