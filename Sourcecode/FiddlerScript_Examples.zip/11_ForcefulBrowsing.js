﻿
import System;
import System.Windows.Forms;
import System.Drawing;
import System.Environment;
import System.String;
import System.Collections.Generic;
import Fiddler;


class Handlers
{          
    static var oPageForcefulBrowsing: TabPage = null; 
    static var oLV: ListView = null; 
    //static var oDomain: String = "www.tcs.com";
    static var oPathlist: String[] = null;
    static var oCounter: int = 0;
    
    
    public static ToolsAction("G0S: Forceful Browsing")
    function ResetForcefulBrowsing() 
    { 
        oLV.Items.Clear();
    }        
    
    public static ContextAction("G0S: Run Forceful Browsing on Url")
    function RunForcefulBrowsing()
    {
        //GeneratePathUrl("http://www.tcs.com/news_events/Pages/default.aspx")
        var sBaseUrl: String;
        sBaseUrl = FiddlerObject.prompt("Entered Urls will be used to derive  Urls for forceful browsing", "", "Enter URL to attack");
        
        if(String.Empty != sBaseUrl)
        {
            ForcefulBrowsingUrl(sBaseUrl);
        }
    }

    public static ContextAction("G0S: Run Forceful Browsing on Selected Session(s)")
    function RunForcefulBrowsing(oSessions: Session[])
    {        
        for(var x:int = 0; x < oSessions.Length; x++)
        {
            //if(oSessions[x].hostname.Contains(oDomain))
            {        
                ForcefulBrowsingUrl(oSessions[x].fullUrl);
            }   
        }
    }
            
    static function OnBoot()
    {
        oPageForcefulBrowsing = new TabPage("G0S: Forceful Browsing");                   
        oPageForcefulBrowsing.Name = "Forceful_Browsing";
                                
        oLV = new ListView();
        oLV.View = View.Details;
        oLV.GridLines = true;
        oLV.FullRowSelect = true;            
        oLV.Columns.Add("Category", 200, HorizontalAlignment.Left);
        oLV.Columns.Add("Severity", 80, HorizontalAlignment.Left);
        oLV.Columns.Add("SessionID", 70, HorizontalAlignment.Left);
        oLV.Columns.Add("Url", 280, HorizontalAlignment.Left);
        oLV.Columns.Add("Description", 300, HorizontalAlignment.Left);
        
        oLV.Dock = DockStyle.Fill;
        oPageForcefulBrowsing.Controls.Add(oLV);
        
        FiddlerApplication.UI.tabsViews.TabPages.Add(oPageForcefulBrowsing);    
    }
                        
    static function Main() 
    {
        if(oLV != null)
        {
            oLV.Items.Clear();   
        }                
    }          
                    
    static function OnBeforeResponse(oSession: Session)
    {
        //ForcefulBrowsingUrl(oSession.fullUrl);
    }
    
    static function ForcefulBrowsingUrl(objUrl: String)
    {        
                
        var _szPath: String = "";
        var _sTemp: String = "";
        var _szUrl: String = "";
        
        var _uriResult: Uri = null;        
        _uriResult = new Uri(objUrl);
        
        var _sDomain = _uriResult.Host;        
        
        for (var x = 0; x < _uriResult.Segments.Length; x++)  
        {
            _sTemp = _uriResult.Segments[x];
            _szPath = _szPath + _sTemp;            
            _szUrl = _sDomain + _szPath;            
            
            var oLVItem = new ListViewItem();
            oLVItem.ForeColor = Color.Black;
            oLVItem.Text = "test";            
            oLVItem.SubItems.Add("None");
            oLVItem.SubItems.Add("hi");        
            oLVItem.SubItems.Add(_szUrl);        
            oLVItem.SubItems.Add("**************");
            
            oLV.Items.Add(oLVItem);
            
            SendRawRequest(_sDomain, _szPath);
        }  
    }    
    
    static function SendRawRequest(sDomain: String, sUrl : String)
    {
        var s = "GET " + sUrl + " HTTP/1.0\r\n" + "Host:" + sDomain + "\r\n\r\n";         
        FiddlerObject.utilIssueRequest(s);                      
    }                                                                          
}    
