﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace AppFingerPrint
{
    public partial class MyControl : UserControl
    {
        private readonly Object m_oLock = new Object();        

        public MyControl()
        {
            InitializeComponent();
        }

 
        #region Operations

        public TabPage GetResultsTab()
        {
            return this.tabControl1.TabPages["PageResults"];
        }

        private void AddRTFMessage(string sMessage)
        {
            RichTextBox _rtbResult = (RichTextBox)GetResultsTab().Controls["rtbResults"];
            _rtbResult.AppendText(Environment.NewLine + sMessage);            
        }

        public void MainFingetPrint(Fiddler.Session oSession)
        {            
            if (chkIsEnabled.Checked)
            {                
                StringBuilder _sBuilder = new StringBuilder();
                string _sTemp = "";
                //_sBuilder.AppendLine(Environment.NewLine + oSession.id.ToString() + " - " + oSession.fullUrl);
                
                _sTemp = HeaderCheck(oSession);
                
                if (!String.IsNullOrEmpty(_sTemp))
                {
                    _sBuilder.AppendLine(_sTemp);
                }
                
                _sTemp = CookieCheck(oSession);
                if (!String.IsNullOrEmpty(_sTemp))
                {
                    _sBuilder.AppendLine(_sTemp);
                }

                _sTemp = ExtensionCheck(oSession);
                if (!String.IsNullOrEmpty(_sTemp))
                {
                    _sBuilder.AppendLine(_sTemp);
                }

                _sTemp = DirCheck(oSession);
                if (!String.IsNullOrEmpty(_sTemp))
                {
                    _sBuilder.AppendLine(_sTemp);
                }

                _sTemp = ResponseCheck(oSession);
                if (!String.IsNullOrEmpty(_sTemp))
                {
                    _sBuilder.AppendLine(_sTemp);
                }

                string _sProcessTemp = _sBuilder.ToString().Trim();
                if (!String.IsNullOrEmpty(_sProcessTemp))
                {
                    _sProcessTemp = Environment.NewLine + oSession.id.ToString() + " - " + oSession.fullUrl + Environment.NewLine + _sProcessTemp;
                    lock (m_oLock)
                    {
                        AddRTFMessage(_sProcessTemp);
                    }
                }
            }            
        }

        private void btnClearResults_Click(object sender, EventArgs e)
        {            
            RichTextBox _rtbResult = (RichTextBox)GetResultsTab().Controls["rtbResults"];
            _rtbResult.Text = "";
        }

        #endregion Operations

        #region Checks

        private string HeaderCheck(Fiddler.Session oSession)
        {
            string _sRetVal = "";

            foreach (KeyValuePair<string, MyCheck> _kvp in m_oResHeaderDictionary)
            {
                if (_kvp.Value.m_bIsChecked)
                {
                    if (oSession.oResponse.headers.Exists(_kvp.Key))
                    {
                        _sRetVal = _kvp.Key + ": "+ oSession.oResponse.headers[_kvp.Key];
                        break;
                    }
                }
            }

            return _sRetVal;
        }

        private string ExtensionCheck(Fiddler.Session oSession)
        {
            string _sRetVal = "";

            foreach (KeyValuePair<string, MyCheck> _kvp in m_oExtensionDictionary)
            {
                if (_kvp.Value.m_bIsChecked)
                {
                    if (oSession.url.EndsWith(_kvp.Key))
                    {
                        _sRetVal = _kvp.Value.m_sDescription;
                        break;
                    }
                }
            }

            return _sRetVal.Trim();
        }

        private string CookieCheck(Fiddler.Session oSession)
        {
            string _sRetVal = "";
            if (oSession.oResponse.headers.Exists("Set-Cookie"))
            {
                string _sCookie = oSession.oResponse.headers["Set-Cookie"];
                foreach (KeyValuePair<string, MyCheck> _kvp in m_oCookieDictionary)
                {
                    if (_kvp.Value.m_bIsChecked)
                    {
                        if (_sCookie.Contains(_kvp.Key))
                        {
                            _sRetVal = _kvp.Value.m_sDescription;
                            break;
                        }
                    }
                }
            }
            return _sRetVal.Trim();
        }

        private string DirCheck(Fiddler.Session oSession)
        {
            string _sRetVal = "";
            string _sUrl = oSession.url;

            foreach (KeyValuePair<string, MyCheck> _kvp in m_oDirDictionary)
            {
                if (_kvp.Value.m_bIsChecked)
                {
                    if (_sUrl.Contains(_kvp.Key))
                    {
                        _sRetVal = _kvp.Value.m_sDescription;
                        break;
                    }
                }
            }
            return _sRetVal.Trim();
        }

        private string ResponseCheck(Fiddler.Session oSession)
        {
            string _sRetVal = "";

            if (oSession.oResponse.headers.ExistsAndContains("Content-Type", "text/html"))
            {
                string _sResponse = "";
                if (oSession.oResponse.headers.Exists("Transfer-Encoding") || oSession.oResponse.headers.Exists("Content-Encoding"))
                {
                    oSession.utilDecodeResponse();
                    _sResponse = System.Text.Encoding.UTF8.GetString(oSession.responseBodyBytes);
                }
                else
                {
                    _sResponse = oSession.GetResponseBodyAsString();
                }

                foreach (KeyValuePair<string, MyCheck> _kvp in m_oResponseDictionary)
                {
                    if (_kvp.Value.m_bIsChecked)
                    {
                        if (_sResponse.Contains(_kvp.Key))
                        {
                            _sRetVal = _kvp.Value.m_sDescription;
                            break;
                        }
                    }
                }
            }
            return _sRetVal.Trim();
        }
        #endregion Checks


        

        
        

    }
}
