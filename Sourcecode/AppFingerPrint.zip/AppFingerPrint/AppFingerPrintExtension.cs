﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

//Theory: https://www.owasp.org/index.php/Web-metadata
//http://anantshri.info/articles/web_app_finger_printing.html
//Regex tutorial - http://www.codeproject.com/Articles/939/An-Introduction-to-Regular-Expressions

[assembly: Fiddler.RequiredVersion("4.4.5.1")]
namespace AppFingerPrint
{
    public class AppFingerPrintExtension : IAutoTamper
    {
        private TabPage m_oPage;
        private MyControl m_oView;
        private bool m_bStarted = false;

        public void OnLoad()
        {            
            /* Load your UI here */
            //icon was created using http://www.xiconeditor.com/Faq.aspx
            FiddlerApplication.UI.imglSessionIcons.Images.Add(Resources.AFP);

            m_oPage = new TabPage("AppFingerPrint");
            m_oPage.ImageIndex = (int)FiddlerApplication.UI.imglSessionIcons.Images.Count - 1;

            m_oView = new MyControl();

            try
            {
                m_oView.InitializeConfigurations();

                m_oView.Dock = DockStyle.Fill;
                m_oPage.Controls.Add(m_oView);

                m_oView.InitializeGUIControls();

                FiddlerApplication.UI.tabsViews.TabPages.Add(m_oPage);

                m_bStarted = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void OnBeforeUnload()
        {

        }

        public void AutoTamperRequestBefore(Session oSession)
        {

        }

        public void AutoTamperRequestAfter(Session oSession)
        {

        }

        public void AutoTamperResponseBefore(Session oSession)
        {            
            
        }

        public void AutoTamperResponseAfter(Session oSession)
        {
            // Ignore proxy requests
            if ((oSession.oRequest.headers.HTTPMethod.Equals("CONNECT")))
            {                
                return;
            }

            if (m_bStarted)
                m_oView.MainFingetPrint(oSession);
        }

        public void OnBeforeReturningError(Session oSession)
        {

        }
    }
}
