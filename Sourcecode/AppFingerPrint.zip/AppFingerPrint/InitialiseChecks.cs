﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace AppFingerPrint
{
    public partial class MyControl : UserControl
    {

        #region Initialize
        class MyCheck
        {
            public string m_sCategory = "";
            public bool m_bIsChecked = true;
            public string m_sCheck = "";
            public string m_sValue = "";
            public string m_sDescription = "";
        }

        Dictionary<string, MyCheck> m_oResHeaderDictionary = new Dictionary<string, MyCheck>();
        Dictionary<string, MyCheck> m_oExtensionDictionary = new Dictionary<string, MyCheck>();
        Dictionary<string, MyCheck> m_oCookieDictionary = new Dictionary<string, MyCheck>();
        Dictionary<string, MyCheck> m_oDirDictionary = new Dictionary<string, MyCheck>();
        Dictionary<string, MyCheck> m_oResponseDictionary = new Dictionary<string, MyCheck>();

        string[] m_sSeparators = null; 

        public enum CHECKS
        {
            RESPONSEHEADER = 1,
            FILEEXTENSION = 2,
            COOKIE = 3,
            DIRECTORY = 4,
            RESPONSE = 5
        }

        string[] m_sResHeader = 
        {
            "Server",
            "X-Powered-By"
        };

        string[] m_sFileExtension = 
        {
            ".aspx###Language- ASP.NET",
            ".jsp###Language- Java (jsp)",
            ".do###Language- Java (struts)",
            ".php###Language- Php",
            ".php3###Language- Php"
        };

        string[] m_sCookie = 
        {
            "ASPSESSION###Cookie by ASP.NET",
            "JSESSION###Cookie by JEE",
            "PHPSESS###Cookie by PHP"
        };

        string[] m_sPath = 
        {
            "/wp-content/###CMS-Wordpress",
            "/wp-includes/###CMS-Wordpress",
            "/wp-admin/###CMS-Wordpress"
        };

        string[] m_sResponse = 
        {
            "<meta name=\"generator\" content=\"Joomla###Joomla",
            "<script src=\"http://code.jquery.com/jquery###JQuery",
            "<meta name=\"author\" content=\"jQuery Foundation###JQuery"
        };

        string[] m_sCategory = 
        {
            "Response Header",
            "File Extension",
            "Cookie",
            "Directory",
            "Response"
        };

        string[] m_sResheaderIdenMethod = 
        {
            "Exists",
        };

        string[] m_sFileExtIdenMethod = 
        {
            "Url Ends With",
        };

        string[] m_sCookieIdenMethod = 
        {
            "Contains",
        };

        string[] m_sDirectoryIdenMethod = 
        {
            "Url Contains",
        };

        string[] m_sResponseIdenMethod = 
        {
            "Contains Keyword",
        };

        private void InitializeDictionary(int nCheckType, string[] sCheckCollection, Dictionary<string, MyCheck> oDictionary)
        {
            oDictionary.Clear();
            foreach (string sItem in sCheckCollection)
            {
                if (!String.IsNullOrEmpty(sItem.Trim()))
                {
                    MyCheck _oCheck = new MyCheck();

                    switch (nCheckType)
                    {
                        case (int)CHECKS.RESPONSEHEADER:
                            _oCheck.m_sCategory = "Response Header";                            
                            _oCheck.m_sCheck = "Exists";
                            break;
                        case (int)CHECKS.FILEEXTENSION:
                            _oCheck.m_sCategory = "File Extension";
                            _oCheck.m_sCheck = "Url Ends With";
                            break;
                        case (int)CHECKS.COOKIE:
                            _oCheck.m_sCategory = "Cookie";
                            _oCheck.m_sCheck = "Contains";
                            break;
                        case (int)CHECKS.DIRECTORY:
                            _oCheck.m_sCategory = "Directory";
                            _oCheck.m_sCheck = "Url Contains";
                            break;
                        case (int)CHECKS.RESPONSE:
                            _oCheck.m_sCategory = "Response";
                            _oCheck.m_sCheck = "Contains Keyword";
                            break;
                        default:
                            _oCheck.m_sCategory = "Unknown";
                            _oCheck.m_sCheck = "Unknown";
                            break;
                    }
                    
                    _oCheck.m_bIsChecked = true;

                    string[] sChecks = sItem.Split(m_sSeparators, StringSplitOptions.None);
                    if (sChecks.Length > 1)
                    {
                        _oCheck.m_sValue = sChecks[0];
                        _oCheck.m_sDescription = sChecks[1];
                    }
                    else
                    {
                        _oCheck.m_sValue = sItem;

                    }

                    if (!String.IsNullOrEmpty(_oCheck.m_sValue.Trim()))
                    {
                        oDictionary.Add(_oCheck.m_sValue, _oCheck);
                    }
                }
            }
        }

        public void InitializeConfigurations()
        {
            m_sSeparators = new string[] { "###" };
            try
            {
                //InitializeResHeaderDictionary(m_sResHeader);
                InitializeDictionary((int)CHECKS.RESPONSEHEADER, m_sResHeader, m_oResHeaderDictionary);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception while initializing Response Header Check: " + ex.Message);
            }

            try
            {
                //InitializeFileExtensionDictionary(m_sFileExtension);
                InitializeDictionary((int)CHECKS.FILEEXTENSION, m_sFileExtension, m_oExtensionDictionary);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception while initializing File Extension Check: " + ex.Message);
            }

            try
            {
                //InitializeCookieDictionary(m_sCookie);
                InitializeDictionary((int)CHECKS.COOKIE, m_sCookie, m_oCookieDictionary);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception while initializing Cookie Check: " + ex.Message);
            }

            try
            {
                //InitializePathDictionary(m_sPath);
                InitializeDictionary((int)CHECKS.DIRECTORY, m_sPath, m_oDirDictionary);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception while initializing Directory Check: " + ex.Message);
            }

            try
            {
                //InitializeResponseDictionary(m_sResponse);
                InitializeDictionary((int)CHECKS.RESPONSE, m_sResponse, m_oResponseDictionary);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception while initializing Response Check: " + ex.Message);
            }

            rtbResults.Text = "Visit following Urls:"
                              + Environment.NewLine + "http://g0s.org/"              
                              + Environment.NewLine + "http://fiddler2.com/"                              
                              + Environment.NewLine + "http://msdn.microsoft.com/"
                              + Environment.NewLine + "http://jquery.com/"
                              + Environment.NewLine + "www.google.co.in";
        }

        public void InitializeGUIControls()
        {            
            InitializeGUI();
            FromObjectToGUI();
        }
        /* Working Routines
        private void InitializeResHeaderDictionary(string[] sResheaderCheck)
        {
            m_oExtensionDictionary.Clear();
            foreach (string sItem in sResheaderCheck)
            {
                if (!String.IsNullOrEmpty(sItem.Trim()))
                {
                    MyCheck _oCheck = new MyCheck();
                    _oCheck.m_sCategory = "Response Header";
                    _oCheck.m_bIsChecked = true;
                    _oCheck.m_sCheck = "Exists";

                    string[] sChecks = sItem.Split(m_sSeparators, StringSplitOptions.None);
                    if (sChecks.Length > 1)
                    {
                        _oCheck.m_sValue = sChecks[0];
                        _oCheck.m_sDescription = sChecks[1];
                    }
                    else
                    {
                        _oCheck.m_sValue = sItem;

                    }

                    if (!String.IsNullOrEmpty(_oCheck.m_sValue.Trim()))
                    {
                        m_oResHeaderDictionary.Add(_oCheck.m_sValue, _oCheck);
                    }
                }
            }
        }
        private void InitializeFileExtensionDictionary(string[] sFileExtensionCheck)
        {
            m_oExtensionDictionary.Clear();
            foreach (string sItem in sFileExtensionCheck)
            {
                if (!String.IsNullOrEmpty(sItem.Trim()))
                {
                    MyCheck _oCheck = new MyCheck();
                    _oCheck.m_sCategory = "File Extension";
                    _oCheck.m_bIsChecked = true;
                    _oCheck.m_sCheck = "Url Ends With";

                    string[] sChecks = sItem.Split(m_sSeparators, StringSplitOptions.None);
                    if (sChecks.Length > 1)
                    {
                        _oCheck.m_sValue = sChecks[0];
                        _oCheck.m_sDescription = sChecks[1];
                    }
                    else
                    {
                        _oCheck.m_sValue = sItem;

                    }

                    if (!String.IsNullOrEmpty(_oCheck.m_sValue.Trim()))
                    {
                        m_oExtensionDictionary.Add(_oCheck.m_sValue, _oCheck);
                    }
                }
            }
        }
        private void InitializeCookieDictionary(string[] sCookie)
        {
            m_oCookieDictionary.Clear();
            foreach (string sItem in sCookie)
            {
                if (!String.IsNullOrEmpty(sItem.Trim()))
                {
                    MyCheck _oCheck = new MyCheck();
                    _oCheck.m_sCategory = "Cookie";
                    _oCheck.m_bIsChecked = true;
                    _oCheck.m_sCheck = "Cookie Contains";

                    string[] sChecks = sItem.Split(m_sSeparators, StringSplitOptions.None);
                    if (sChecks.Length > 1)
                    {
                        _oCheck.m_sValue = sChecks[0];
                        _oCheck.m_sDescription = sChecks[1];
                    }
                    else
                    {
                        _oCheck.m_sValue = sItem;
                    }

                    if (!String.IsNullOrEmpty(_oCheck.m_sValue.Trim()))
                    {
                        m_oCookieDictionary.Add(_oCheck.m_sValue, _oCheck);
                    }
                }
            }
        }
        private void InitializePathDictionary(string[] sPath)
        {
            m_oDirDictionary.Clear();
            foreach (string sItem in sPath)
            {
                if (!String.IsNullOrEmpty(sItem.Trim()))
                {
                    MyCheck _oCheck = new MyCheck();
                    _oCheck.m_sCategory = "Directory";
                    _oCheck.m_bIsChecked = true;
                    _oCheck.m_sCheck = "Url Contains";

                    string[] sChecks = sItem.Split(m_sSeparators, StringSplitOptions.None);
                    if (sChecks.Length > 1)
                    {
                        _oCheck.m_sValue = sChecks[0];
                        _oCheck.m_sDescription = sChecks[1];
                    }
                    else
                    {
                        _oCheck.m_sValue = sItem;
                    }

                    if (!String.IsNullOrEmpty(_oCheck.m_sValue.Trim()))
                    {
                        m_oDirDictionary.Add(_oCheck.m_sValue, _oCheck);
                    }
                }
            }
        }
        private void InitializeResponseDictionary(string[] sResponse)
        {
            m_oResponseDictionary.Clear();
            foreach (string sItem in sResponse)
            {
                if (!String.IsNullOrEmpty(sItem.Trim()))
                {
                    MyCheck _oCheck = new MyCheck();
                    _oCheck.m_sCategory = "Response";
                    _oCheck.m_bIsChecked = true;
                    _oCheck.m_sCheck = "Contains Keyword";

                    string[] sChecks = sItem.Split(m_sSeparators, StringSplitOptions.None);
                    if (sChecks.Length > 1)
                    {
                        _oCheck.m_sValue = sChecks[0];
                        _oCheck.m_sDescription = sChecks[1];
                    }
                    else
                    {
                        _oCheck.m_sValue = sItem;
                    }

                    if (!String.IsNullOrEmpty(_oCheck.m_sValue.Trim()))
                    {
                        m_oResponseDictionary.Add(_oCheck.m_sValue, _oCheck);
                    }
                }
            }
        }
        */
        private void AddCheckAsListViewItem(MyCheck oMyCheck)
        {
            ListViewItem lvItem = new ListViewItem();
            lvItem.Text = oMyCheck.m_sCategory;
            lvItem.Checked = oMyCheck.m_bIsChecked;
            lvItem.SubItems.Add(oMyCheck.m_sCheck);
            lvItem.SubItems.Add(oMyCheck.m_sValue);
            lvItem.SubItems.Add(oMyCheck.m_sDescription);

            lstViewConfig.Items.Add(lvItem);
        }

        private void FromObjectToGUI()
        {
            try
            {
                lstViewConfig.Items.Clear();
                foreach (KeyValuePair<string, MyCheck> _kvp in m_oResHeaderDictionary)
                {
                    AddCheckAsListViewItem(_kvp.Value);
                }

                foreach (KeyValuePair<string, MyCheck> _kvp in m_oExtensionDictionary)
                {
                    AddCheckAsListViewItem(_kvp.Value);
                }

                foreach (KeyValuePair<string, MyCheck> _kvp in m_oCookieDictionary)
                {
                    AddCheckAsListViewItem(_kvp.Value);
                }

                foreach (KeyValuePair<string, MyCheck> _kvp in m_oDirDictionary)
                {
                    AddCheckAsListViewItem(_kvp.Value);
                }

                foreach (KeyValuePair<string, MyCheck> _kvp in m_oResponseDictionary)
                {
                    AddCheckAsListViewItem(_kvp.Value);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FromGUIToObject()
        {
            m_oResHeaderDictionary.Clear();
            m_oExtensionDictionary.Clear();
            m_oCookieDictionary.Clear();
            m_oDirDictionary.Clear();
            m_oResponseDictionary.Clear();

            foreach (ListViewItem lvItem in this.lstViewConfig.Items)
            {
                if (lvItem.Text.CompareTo("Response Header") == 0)
                {
                    AddListViewItemAsCheck(lvItem, m_oResHeaderDictionary);
                }
                else if (lvItem.Text.CompareTo("File Extension") == 0)
                {
                    AddListViewItemAsCheck(lvItem, m_oExtensionDictionary);
                }
                else if (lvItem.Text.CompareTo("Cookie") == 0)
                {
                    AddListViewItemAsCheck(lvItem, m_oCookieDictionary);
                }
                else if (lvItem.Text.CompareTo("Directory") == 0)
                {
                    AddListViewItemAsCheck(lvItem, m_oDirDictionary);
                }
                else if (lvItem.Text.CompareTo("Response") == 0)
                {
                    AddListViewItemAsCheck(lvItem, m_oResponseDictionary);
                }
            }
        }

        private void AddListViewItemAsCheck(ListViewItem lvItem, Dictionary<string, MyCheck> oDictionary)
        {
            MyCheck _oMyCheck = new MyCheck();
            _oMyCheck.m_sCategory = lvItem.Text;
            _oMyCheck.m_bIsChecked = lvItem.Checked;
            _oMyCheck.m_sCheck = lvItem.SubItems[1].Text;
            _oMyCheck.m_sValue = lvItem.SubItems[2].Text;
            _oMyCheck.m_sDescription = lvItem.SubItems[3].Text;
            oDictionary.Add(_oMyCheck.m_sValue, _oMyCheck);
        }

        private void InitializeGUI()
        {
            try
            {
                lstViewConfig.Columns.Add("Category", 130, HorizontalAlignment.Left);
                lstViewConfig.Columns.Add("Check", 140, HorizontalAlignment.Left);
                lstViewConfig.Columns.Add("Value", 200, HorizontalAlignment.Left);
                lstViewConfig.Columns.Add("Description", -2, HorizontalAlignment.Left);

                cbCategory.Items.AddRange(m_sCategory);
                cbCategory.SelectedIndex = 0;
                cbIdenMethod.Items.AddRange(m_sFileExtIdenMethod);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion Initialize
    }
}