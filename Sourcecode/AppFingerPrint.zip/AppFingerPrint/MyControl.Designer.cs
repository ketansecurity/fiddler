﻿namespace AppFingerPrint
{
    partial class MyControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.PageResults = new System.Windows.Forms.TabPage();
            this.rtbResults = new System.Windows.Forms.RichTextBox();
            this.PageChecks = new System.Windows.Forms.TabPage();
            this.btnInvertSelection = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLoadCheck = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cbIdenMethod = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSaveCheck = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.tbDetails = new System.Windows.Forms.TextBox();
            this.btnApplySelection = new System.Windows.Forms.Button();
            this.lstViewConfig = new System.Windows.Forms.ListView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnClearResults = new System.Windows.Forms.Button();
            this.chkIsEnabled = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbPattern = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.PageResults.SuspendLayout();
            this.PageChecks.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.PageResults);
            this.tabControl1.Controls.Add(this.PageChecks);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(10);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(708, 384);
            this.tabControl1.TabIndex = 0;
            // 
            // PageResults
            // 
            this.PageResults.Controls.Add(this.rtbResults);
            this.PageResults.Location = new System.Drawing.Point(4, 22);
            this.PageResults.Name = "PageResults";
            this.PageResults.Size = new System.Drawing.Size(700, 358);
            this.PageResults.TabIndex = 2;
            this.PageResults.Text = "Results";
            this.PageResults.UseVisualStyleBackColor = true;
            // 
            // rtbResults
            // 
            this.rtbResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbResults.Location = new System.Drawing.Point(0, 0);
            this.rtbResults.Name = "rtbResults";
            this.rtbResults.Size = new System.Drawing.Size(700, 358);
            this.rtbResults.TabIndex = 0;
            this.rtbResults.Text = "";
            // 
            // PageChecks
            // 
            this.PageChecks.Controls.Add(this.btnInvertSelection);
            this.PageChecks.Controls.Add(this.groupBox1);
            this.PageChecks.Controls.Add(this.btnApplySelection);
            this.PageChecks.Controls.Add(this.lstViewConfig);
            this.PageChecks.Location = new System.Drawing.Point(4, 22);
            this.PageChecks.Name = "PageChecks";
            this.PageChecks.Padding = new System.Windows.Forms.Padding(3);
            this.PageChecks.Size = new System.Drawing.Size(700, 358);
            this.PageChecks.TabIndex = 0;
            this.PageChecks.Text = "Checks";
            this.PageChecks.UseVisualStyleBackColor = true;
            // 
            // btnInvertSelection
            // 
            this.btnInvertSelection.Location = new System.Drawing.Point(8, 343);
            this.btnInvertSelection.Name = "btnInvertSelection";
            this.btnInvertSelection.Size = new System.Drawing.Size(120, 29);
            this.btnInvertSelection.TabIndex = 7;
            this.btnInvertSelection.Text = "Invert Selection";
            this.btnInvertSelection.UseVisualStyleBackColor = true;
            this.btnInvertSelection.Click += new System.EventHandler(this.btnInvertSelection_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbPattern);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnLoadCheck);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbIdenMethod);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnSaveCheck);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cbCategory);
            this.groupBox1.Controls.Add(this.tbDetails);
            this.groupBox1.Location = new System.Drawing.Point(8, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(686, 106);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Change Checks";
            // 
            // btnLoadCheck
            // 
            this.btnLoadCheck.Location = new System.Drawing.Point(620, 76);
            this.btnLoadCheck.Name = "btnLoadCheck";
            this.btnLoadCheck.Size = new System.Drawing.Size(60, 24);
            this.btnLoadCheck.TabIndex = 10;
            this.btnLoadCheck.Text = "Load";
            this.btnLoadCheck.UseVisualStyleBackColor = true;
            this.btnLoadCheck.Click += new System.EventHandler(this.btnLoadCheck_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(210, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Identification Method";
            // 
            // cbIdenMethod
            // 
            this.cbIdenMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbIdenMethod.FormattingEnabled = true;
            this.cbIdenMethod.Location = new System.Drawing.Point(322, 17);
            this.cbIdenMethod.Name = "cbIdenMethod";
            this.cbIdenMethod.Size = new System.Drawing.Size(121, 21);
            this.cbIdenMethod.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 26);
            this.label3.TabIndex = 7;
            this.label3.Text = "Details\r\n(Value###Description)";
            // 
            // btnSaveCheck
            // 
            this.btnSaveCheck.Location = new System.Drawing.Point(620, 48);
            this.btnSaveCheck.Name = "btnSaveCheck";
            this.btnSaveCheck.Size = new System.Drawing.Size(60, 26);
            this.btnSaveCheck.TabIndex = 5;
            this.btnSaveCheck.Text = "Save";
            this.btnSaveCheck.UseVisualStyleBackColor = true;
            this.btnSaveCheck.Click += new System.EventHandler(this.btnSaveCheck_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Check Type";
            // 
            // cbCategory
            // 
            this.cbCategory.AutoCompleteCustomSource.AddRange(new string[] {
            "File Extension",
            "Cookie",
            "Directory"});
            this.cbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Location = new System.Drawing.Point(83, 17);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(121, 21);
            this.cbCategory.TabIndex = 2;
            this.cbCategory.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            // 
            // tbDetails
            // 
            this.tbDetails.Location = new System.Drawing.Point(136, 48);
            this.tbDetails.Multiline = true;
            this.tbDetails.Name = "tbDetails";
            this.tbDetails.Size = new System.Drawing.Size(478, 49);
            this.tbDetails.TabIndex = 3;
            // 
            // btnApplySelection
            // 
            this.btnApplySelection.Location = new System.Drawing.Point(598, 343);
            this.btnApplySelection.Name = "btnApplySelection";
            this.btnApplySelection.Size = new System.Drawing.Size(96, 30);
            this.btnApplySelection.TabIndex = 1;
            this.btnApplySelection.Text = "Apply Selection";
            this.btnApplySelection.UseVisualStyleBackColor = true;
            this.btnApplySelection.Click += new System.EventHandler(this.btnApplyChanges_Click);
            // 
            // lstViewConfig
            // 
            this.lstViewConfig.CheckBoxes = true;
            this.lstViewConfig.FullRowSelect = true;
            this.lstViewConfig.GridLines = true;
            this.lstViewConfig.Location = new System.Drawing.Point(8, 116);
            this.lstViewConfig.MultiSelect = false;
            this.lstViewConfig.Name = "lstViewConfig";
            this.lstViewConfig.Size = new System.Drawing.Size(686, 220);
            this.lstViewConfig.TabIndex = 0;
            this.lstViewConfig.UseCompatibleStateImageBehavior = false;
            this.lstViewConfig.View = System.Windows.Forms.View.Details;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnClearResults);
            this.splitContainer1.Panel1.Controls.Add(this.chkIsEnabled);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(708, 468);
            this.splitContainer1.SplitterDistance = 80;
            this.splitContainer1.TabIndex = 1;
            // 
            // btnClearResults
            // 
            this.btnClearResults.Location = new System.Drawing.Point(150, 58);
            this.btnClearResults.Name = "btnClearResults";
            this.btnClearResults.Size = new System.Drawing.Size(96, 30);
            this.btnClearResults.TabIndex = 2;
            this.btnClearResults.Text = "ClearResults";
            this.btnClearResults.UseVisualStyleBackColor = true;
            this.btnClearResults.Click += new System.EventHandler(this.btnClearResults_Click);
            // 
            // chkIsEnabled
            // 
            this.chkIsEnabled.AutoSize = true;
            this.chkIsEnabled.Location = new System.Drawing.Point(9, 60);
            this.chkIsEnabled.Name = "chkIsEnabled";
            this.chkIsEnabled.Size = new System.Drawing.Size(126, 17);
            this.chkIsEnabled.TabIndex = 1;
            this.chkIsEnabled.Text = "Enable this extension";
            this.chkIsEnabled.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Application FingerPrinting ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(524, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Separator Pattern";
            // 
            // tbPattern
            // 
            this.tbPattern.Location = new System.Drawing.Point(620, 17);
            this.tbPattern.Name = "tbPattern";
            this.tbPattern.Size = new System.Drawing.Size(59, 20);
            this.tbPattern.TabIndex = 12;
            this.tbPattern.Text = "###";
            // 
            // MyControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "MyControl";
            this.Size = new System.Drawing.Size(708, 468);
            this.tabControl1.ResumeLayout(false);
            this.PageResults.ResumeLayout(false);
            this.PageChecks.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage PageResults;
        private System.Windows.Forms.TabPage PageChecks;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkIsEnabled;
        private System.Windows.Forms.ListView lstViewConfig;
        private System.Windows.Forms.RichTextBox rtbResults;
        private System.Windows.Forms.Button btnApplySelection;
        private System.Windows.Forms.Button btnSaveCheck;
        private System.Windows.Forms.TextBox tbDetails;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbIdenMethod;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLoadCheck;
        private System.Windows.Forms.Button btnInvertSelection;
        private System.Windows.Forms.Button btnClearResults;
        private System.Windows.Forms.TextBox tbPattern;
        private System.Windows.Forms.Label label5;
    }
}
