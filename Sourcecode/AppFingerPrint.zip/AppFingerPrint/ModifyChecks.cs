﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace AppFingerPrint
{
    public partial class MyControl : UserControl
    {
        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbIdenMethod.Items.Clear();

            if (cbCategory.Text.CompareTo("Response Header") == 0)
            {
                cbIdenMethod.Items.AddRange(m_sResheaderIdenMethod);
                tbDetails.Text = String.Join(",", m_sResHeader);
            }
            else if (cbCategory.Text.CompareTo("File Extension") == 0)
            {
                cbIdenMethod.Items.AddRange(m_sFileExtIdenMethod);
                tbDetails.Text = String.Join(",", m_sFileExtension);
            }
            else if (cbCategory.Text.CompareTo("Cookie") == 0)
            {
                cbIdenMethod.Items.AddRange(m_sCookieIdenMethod);
                tbDetails.Text = String.Join(",", m_sCookie);
            }
            else if (cbCategory.Text.CompareTo("Directory") == 0)
            {
                cbIdenMethod.Items.AddRange(m_sDirectoryIdenMethod);
                tbDetails.Text = String.Join(",", m_sPath);
            }
            else if (cbCategory.Text.CompareTo("Response") == 0)
            {
                cbIdenMethod.Items.AddRange(m_sResponseIdenMethod);
                tbDetails.Text = String.Join(",", m_sResponse);
            }
            cbIdenMethod.SelectedIndex = 0;
        }

        private void btnSaveCheck_Click(object sender, EventArgs e)
        {
            if (cbCategory.Text.CompareTo("Response Header") == 0)
            {
                m_sResHeader = tbDetails.Text.Split(',');
            }
            else if (cbCategory.Text.CompareTo("File Extension") == 0)
            {
                m_sFileExtension = tbDetails.Text.Split(',');
            }
            else if (cbCategory.Text.CompareTo("Cookie") == 0)
            {
                m_sCookie = tbDetails.Text.Split(',');
            }
            else if (cbCategory.Text.CompareTo("Directory") == 0)
            {
                m_sPath = tbDetails.Text.Split(',');
            }
            else if (cbCategory.Text.CompareTo("Response") == 0)
            {
                m_sResponse = tbDetails.Text.Split(',');
            }
        }

        private void btnLoadCheck_Click(object sender, EventArgs e)
        {
            /*
            InitializeResHeaderDictionary(m_sResHeader);
            InitializeFileExtensionDictionary(m_sFileExtension);
            InitializeCookieDictionary(m_sCookie);
            InitializePathDictionary(m_sPath);
            InitializeResponseDictionary(m_sResponse);
            */
            InitializeConfigurations();
            FromObjectToGUI();
        }

        private void btnApplyChanges_Click(object sender, EventArgs e)
        {
            FromGUIToObject();
        }

        private void btnInvertSelection_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvItem in this.lstViewConfig.Items)
            {
                lvItem.Checked = !lvItem.Checked;
            }
        }
    }
}