﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Fiddler;
using System.Windows.Forms;

//http://fiddler2.com/documentation/Extend-Fiddler/ExtendWithDotNet
[assembly: Fiddler.RequiredVersion("4.4.5.1")]
namespace $safeprojectname$
{
    public class MyFiddlerExtensionApp : IAutoTamper
    {
        private TabPage m_oPage;
        private MyControl m_oView;
        private bool m_bStarted = false;

        public void OnLoad()
        {
            m_oPage = new TabPage("My GUI Extension");
            m_oView = new MyControl();
            m_oView.Dock = DockStyle.Fill;
            m_oPage.Controls.Add(m_oView);
            FiddlerApplication.UI.tabsViews.TabPages.Add(m_oPage);

            m_bStarted = true;
        }

        public void OnBeforeUnload() 
        {
            //MessageBox.Show("Extension Removed");
        }

        public void AutoTamperRequestBefore(Session oSession) { }
        public void AutoTamperRequestAfter(Session oSession) { }
        public void AutoTamperResponseBefore(Session oSession) 
        {
            if (m_bStarted)
            {
                m_oView.AddMessage(oSession.id + " - " + oSession.url);
                
                if (oSession.oResponse.headers.Exists("Server"))
                {
                    m_oView.AddMessage("Server: " + oSession.oResponse.headers["Server"]);
                }                
            }
        }
        public void AutoTamperResponseAfter(Session oSession) { }
        public void OnBeforeReturningError(Session oSession) { }
    }
}


