﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MyControl : UserControl
    {
        public MyControl()
        {
            InitializeComponent();
        }

        public void AddMessage(string sMessage)
        {
            RichTextBox _rtbMsg = (RichTextBox)this.Controls["rtbMessage"];
            _rtbMsg.AppendText(Environment.NewLine + sMessage + Environment.NewLine);
        }
    }
}
